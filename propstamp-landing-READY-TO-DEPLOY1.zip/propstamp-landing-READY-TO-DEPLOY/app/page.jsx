import React, { useState } from 'react';
import { CheckCircle, Lock, Zap, BarChart3, ArrowRight } from 'lucide-react';

export default function PropStampLanding() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    // Using Formspree for easy form handling
    try {
      const response = await fetch('https://formspree.io/f/your_form_id', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        setSubmitted(true);
        setFormData({ name: '', email: '', phone: '' });
        setTimeout(() => setSubmitted(false), 5000);
      }
    } catch (error) {
      console.error('Form submission error:', error);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-blue-50 to-white overflow-hidden">
      {/* Navigation */}
      <nav className="flex items-center justify-between px-6 md:px-12 py-6 border-b border-gray-200">
        <div className="flex items-center gap-2">
          <img 
            src="propstamp-logo.png"
            alt="PropStamp Logo - Mark Your Property"
            className="h-16 md:h-20 object-contain"
          />
        </div>
        <div className="text-sm font-medium text-gray-600">Protect Your Property Images</div>
      </nav>

      {/* Hero Section */}
      <section className="relative px-6 md:px-12 py-16 md:py-28">
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            
            {/* Left Content */}
            <div className="space-y-8 animate-fade-in">
              <div className="space-y-6">
                <div className="flex justify-start">
                  <img 
                    src="propstamp-logo.png"
                    alt="PropStamp Logo - Mark Your Property"
                    className="h-40 md:h-56 object-contain"
                  />
                </div>
                <h1 className="text-5xl md:text-6xl font-bold leading-tight text-gray-900">
                  Stop Property Image Theft.<br />
                  <span className="text-blue-600">Start Protecting.</span>
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed">
                  Add your branded watermark and logo to every property photo. Prevent competitors from stealing your listings and building credibility from your work.
                </p>
              </div>

              {/* Key Benefits */}
              <div className="space-y-4 pt-4">
                {[
                  { icon: Lock, text: 'Protect your property images from theft' },
                  { icon: Zap, text: 'Brand every photo with your logo instantly' },
                  { icon: BarChart3, text: 'Build brand recognition with every listing' }
                ].map((item, idx) => (
                  <div key={idx} className="flex gap-4 items-start">
                    <div className="flex-shrink-0 mt-1">
                      <item.icon className="w-6 h-6 text-orange-500" />
                    </div>
                    <p className="text-lg text-gray-700">{item.text}</p>
                  </div>
                ))}
              </div>

              {/* CTA */}
              <button className="inline-flex items-center gap-3 px-8 py-4 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-all hover:gap-4 text-lg shadow-lg hover:shadow-xl">
                Get Early Access <ArrowRight className="w-5 h-5" />
              </button>
            </div>

            {/* Right - Lead Form */}
            <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100 sticky top-20">
              <div className="space-y-6">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">Try PropStamp Free</h2>
                  <p className="text-gray-600">Join brokers protecting their images today</p>
                </div>

                {submitted && (
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg flex gap-3">
                    <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-green-900">Thanks for joining!</p>
                      <p className="text-sm text-green-700">We'll be in touch shortly.</p>
                    </div>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      placeholder="John Smith"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Email *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      placeholder="john@realestate.com"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      placeholder="+1 (555) 000-0000"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 bg-orange-500 text-white font-semibold rounded-lg hover:bg-orange-600 transition-all disabled:opacity-50 text-lg shadow-md hover:shadow-lg"
                  >
                    {loading ? 'Sending...' : 'Get Free Trial'}
                  </button>
                </form>

                <p className="text-xs text-gray-500 text-center">
                  No credit card required. We'll contact you within 24 hours.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="bg-gray-50 py-20 px-6 md:px-12">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">How PropStamp Works</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { num: '1', title: 'Upload Photos', desc: 'Drop your property images into PropStamp' },
              { num: '2', title: 'Add Your Branding', desc: 'Choose logo placement, transparency & size' },
              { num: '3', title: 'Protect & Share', desc: 'Download watermarked photos. Your brand stays on every image.' }
            ].map((step, idx) => (
              <div key={idx} className="text-center space-y-4">
                <div className="w-16 h-16 mx-auto bg-blue-600 text-white rounded-full flex items-center justify-center text-3xl font-bold">
                  {step.num}
                </div>
                <h3 className="text-xl font-bold text-gray-900">{step.title}</h3>
                <p className="text-gray-600">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-16 px-6 md:px-12 bg-white">
        <div className="max-w-5xl mx-auto text-center">
          <p className="text-gray-600 font-semibold mb-8">Trusted by brokers in</p>
          <div className="flex justify-center items-center gap-8 text-gray-400 text-lg font-semibold flex-wrap">
            <span>California</span>
            <span>•</span>
            <span>Texas</span>
            <span>•</span>
            <span>Florida</span>
            <span>•</span>
            <span>New York</span>
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-700 py-16 px-6 md:px-12">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <h2 className="text-4xl font-bold text-white">Ready to Protect Your Listings?</h2>
          <p className="text-xl text-blue-100">Join dozens of brokers already using PropStamp</p>
          <button className="inline-flex items-center gap-3 px-8 py-4 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition-all text-lg shadow-lg">
            Start Your Free Trial <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-8 px-6 md:px-12">
        <div className="max-w-5xl mx-auto text-center text-sm">
          <p>&copy; 2024 PropStamp. All rights reserved. | Protecting Property Images Globally</p>
        </div>
      </footer>

      <style jsx>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fade-in {
          animation: fadeIn 0.8s ease-out;
        }
      `}</style>
    </div>
  );
}
