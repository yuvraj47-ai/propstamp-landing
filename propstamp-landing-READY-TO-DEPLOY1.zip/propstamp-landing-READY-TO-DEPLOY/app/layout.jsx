import './globals.css'

export const metadata = {
  title: 'PropStamp - Protect Your Property Images',
  description: 'Stop property image theft. Add your branded watermark to every photo instantly.',
  viewport: 'width=device-width, initial-scale=1',
  keywords: 'real estate, watermark, branding, property images, real estate marketing',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
